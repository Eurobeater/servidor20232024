<?php
class PollModel
{
    protected $db;
 
    private $poll_id;
	
    public function __construct()
    {
        //Traemos la única instancia de PDO
        $this->db = SPDO::singleton();
    }
 
    public function getPoll_id()
    {
        return $this->poll_id;
    }
    
    
    public function getById( $encuesta_id )
    {
        //realizamos la consulta de todos los items
        $consulta = $this->db->prepare('SELECT * FROM POLL_ENCUESTAS where ENCUESTA_ID = ?');
        $consulta->bindParam( 1, $encuesta_id );
        $consulta->execute();
         
        $gsent->setFetchMode(PDO::FETCH_CLASS, "EncuestaModel");
        $resultado = $gsent->fetch();
                
        return $resultado;
    }
	
	public function save()
    {if( ! isset( $this->poll_id ) )
        {
			$consulta = $this->db->prepare('insert into poll_polls ( fecha, hora ) VALUES( ?, ? )');
            
            $consulta->bindParam( 1,  $this->fecha );
            $consulta->bindParam( 2,  $this->hora );
            $resultado = $consulta->execute();
            $this->poll_id = $this->db->lastInsertId();
        }
        else
        {
            $consulta = $this->db->prepare('update poll_polls set fecha = ?, hora = ?  where poll_id = ?');
            
            $consulta->bindParam( 1,  $this->fecha );
            $consulta->bindParam( 2,  $this->hora );
            $consulta->bindParam( 3,  $this->poll_id );
            
            $resultado = $consulta->execute();
        }
        
        return $resultado;
    }
    
	
	
	
}
?>