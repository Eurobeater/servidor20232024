<?php
class ResultadoModel
{
    protected $db;
 
    private $resultado_id;
	private $poll_id;
	private $respuesta_id;
    public function __construct()
    {
        //Traemos la única instancia de PDO
        $this->db = SPDO::singleton();
    }
 
    public function getResultado_id()
    {
        return $this->encuesta_id;
    }
    public function setPoll_id( $value )
    {
        return $this->poll_id = $value;
    }
	public function setRespuesta_id( $value )
    {
        return $this->respuesta_id = $value;
    }
	public function save()
    {
		
        
        
        if( ! isset( $this->resultado_id ) )
        {
			$consulta = $this->db->prepare('insert into poll_resultados ( poll_id, respuesta_id ) values  ( ?, ? )');
            
            $consulta->bindParam( 1,  $this->poll_id );
            $consulta->bindParam( 2,  $this->respuesta_id );
            $resultado = $consulta->execute();
            $this->resultado_id = $this->db->lastInsertId();
        }
        else
        {
            $consulta = $this->db->prepare('update poll_resultados set poll_id = ?, respuesta_id  where resultado_id = ?');
            
            $consulta->bindParam( 1,  $this->poll_id );
            $consulta->bindParam( 2,  $this->respuesta_id );
            $consulta->bindParam( 3,  $this->resultado_id );
            
            $resultado = $consulta->execute();
        }
        
        return $resultado;
    }
    
	
	
	
}
?>