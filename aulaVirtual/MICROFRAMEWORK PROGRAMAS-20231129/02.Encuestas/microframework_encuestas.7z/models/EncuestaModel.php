<?php
class EncuestaModel
{
    protected $db;
 
    private $encuesta_id;
    private $encuesta;
    
    public function __construct()
    {
        //Traemos la única instancia de PDO
        $this->db = SPDO::singleton();
    }
 
    public function getEncuesta_id()
    {
        return $this->encuesta_id;
    }
    public function setEncuesta_id( $encuesta_id )
    {
        return $this->encuesta_id = $encuesta_id;
    }
    
    public function getEncuesta()
    {
        return $this->encuesta;
    }
    public function setEncuesta( $value )
    {
        return $this->encuesta = $value;
    }
    
    public function getAll()
    {
        
        $gsent = $this->db->prepare('SELECT * FROM POLL_ENCUESTAS');
        $gsent->execute();

        $resultado = $gsent->fetchAll(PDO::FETCH_CLASS, "EncuestaModel");
        return $resultado;
    }
    
    
    public function getById( $encuesta_id )
    {
        //realizamos la consulta de todos los items
        $consulta = $this->db->prepare('SELECT * FROM POLL_ENCUESTAS where ENCUESTA_ID = ?');
        $consulta->bindParam( 1, $encuesta_id );
        $consulta->execute();
         
        $gsent->setFetchMode(PDO::FETCH_CLASS, "EncuestaModel");
        $resultado = $gsent->fetch();
                
        return $resultado;
    }
	
	
	
	
	
}
?>