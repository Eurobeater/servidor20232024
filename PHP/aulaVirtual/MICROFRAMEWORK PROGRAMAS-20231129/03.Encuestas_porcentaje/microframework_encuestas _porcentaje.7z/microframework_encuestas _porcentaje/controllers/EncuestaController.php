<?php
class EncuestaController
{
	public $view;

    function __construct()
    {
        //Creamos una instancia de nuestro mini motor de plantillas
        $this->view = new View();
    }
 
 
    
 
    public function listarEncuestas()
    {
        //Incluye el modelo que corresponde
        require 'models/EncuestaModel.php';
 
        //Creamos una instancia de nuestro "modelo"
        $encuestas = new EncuestaModel();
 
        //Le pedimos al modelo todos los encuestas
        $listado = $encuestas->getAll();
 
        //Pasamos a la vista toda la información que se desea representar
        $data['encuestas'] = $listado;
 
        
        //Finalmente presentamos nuestra plantilla
        $this->view->show("ListarEncuestasView.php", $data);
		

    }
	
	
	public function listarPreguntasRespuestas()
    {
        //Incluye el modelo que corresponde
        require 'models/PreguntaModel.php';
		require 'models/PollModel.php';
		require 'models/ResultadoModel.php';
		
        //Creamos una instancia de nuestro "modelo"
        $pregunta = new PreguntaModel();
		$poll = new PollModel();
		$resultado = new ResultadoModel();

		
		
		
		$preguntas= $pregunta->getPreguntasByEncuesta($_REQUEST[ 'encuesta_id']);
		if( isset($_REQUEST[ 'submit'] ))
		{
			$poll->save();	
			foreach( $preguntas as $pregunta )
			{
						
				
				if( isset( $_REQUEST[ 'pregunta'.$pregunta['pregunta_id']]) && $_REQUEST[ 'pregunta'.$pregunta['pregunta_id']] == $pregunta['respuesta_id'] )
				{
					$resultado = new ResultadoModel();
					$resultado->setPoll_id( $poll->getPoll_id());
					$resultado->setRespuesta_id( $_REQUEST[ 'pregunta'.$pregunta['pregunta_id']]);
					$resultado->save();
					
					
				}	
			}
			$resultado = new ResultadoModel();
			$resultados = $resultado->getResultados( $_REQUEST[ 'encuesta_id']);

			$this->view->show("ListarResultados.php", [ "preguntas" =>$resultados ]);
		}
		else
		{    
       
			//Finalmente presentamos nuestra plantilla
			$this->view->show("ListarPreguntasView.php", [ 'preguntas' => $preguntas, 'encuesta_id' => $_REQUEST[ 'encuesta_id']]);
		}
    }
    
    
}
?>