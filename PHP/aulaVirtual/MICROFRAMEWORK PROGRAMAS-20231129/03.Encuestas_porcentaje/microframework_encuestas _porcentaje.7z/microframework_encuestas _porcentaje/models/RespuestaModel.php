<?php
class PreguntaModel
{
    protected $db;
 
    private $codigo;
    private $pregunta;
    
    public function __construct()
    {
        //Traemos la única instancia de PDO
        $this->db = SPDO::singleton();
    }
 
    public function getCodigo()
    {
        return $this->codigo;
    }
    public function setCodigo( $codigo )
    {
        return $this->codigo = $codigo;
    }
    
    public function getPregunta()
    {
        return $this->pregunta;
    }
    public function setPregunta( $value )
    {
        return $this->pregunta = $value;
    }
    
    public function getAll()
    {
        
        $gsent = $this->db->prepare('SELECT * FROM POLL_PREGUNTAS');
        $gsent->execute();

        $resultado = $gsent->fetchAll(PDO::FETCH_CLASS, "PreguntaModel");
        return $resultado;
    }
    
    
     public function getById( $codigo )
    {
        //realizamos la consulta de todos los items
        $consulta = $this->db->prepare('SELECT * FROM POLL_PREGUNTAS where ENCUESTA_ID = ?');
        $consulta->bindParam( 1, $codigo );
        $consulta->execute();
         
        $gsent->setFetchMode(PDO::FETCH_CLASS, "PreguntaModel");
        $resultado = $gsent->fetch();
                
        return $resultado;
    }
	
}
?>