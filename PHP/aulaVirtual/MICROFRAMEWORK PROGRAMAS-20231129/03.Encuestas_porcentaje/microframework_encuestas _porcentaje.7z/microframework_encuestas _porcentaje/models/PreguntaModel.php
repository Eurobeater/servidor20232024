<?php
class PreguntaModel
{
    protected $db;
 
    private $pregunta_id;
    private $pregunta;
    
    public function __construct()
    {
        //Traemos la única instancia de PDO
        $this->db = SPDO::singleton();
    }
 
    
    
	
	public function getPreguntasByEncuesta($codigo)
    {
        
        $consulta = $this->db->prepare('SELECT * FROM poll_preguntas, poll_respuestas WHERE poll_respuestas.pregunta_id = poll_preguntas.pregunta_id and poll_preguntas.encuesta_id = ? order by poll_preguntas.orden, poll_respuestas.orden');
        $consulta->bindParam( 1, $codigo );
        $consulta->execute();
         
        
        $resultado = $consulta->fetchAll();
                
        return $resultado;
    }
	

}
?>