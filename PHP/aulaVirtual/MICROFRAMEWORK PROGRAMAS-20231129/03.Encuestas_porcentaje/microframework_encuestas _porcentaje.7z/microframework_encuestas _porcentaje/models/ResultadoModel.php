<?php
class ResultadoModel
{
    protected $db;
 
    private $resultado_id;
	private $poll_id;
	private $respuesta_id;
    public function __construct()
    {
        //Traemos la única instancia de PDO
        $this->db = SPDO::singleton();
    }
 
    public function getResultado_id()
    {
        return $this->encuesta_id;
    }
    public function setPoll_id( $value )
    {
        return $this->poll_id = $value;
    }
	public function setRespuesta_id( $value )
    {
        return $this->respuesta_id = $value;
    }
	public function save()
    {
		
        
        
        if( ! isset( $this->resultado_id ) )
        {
			$consulta = $this->db->prepare('insert into poll_resultados ( poll_id, respuesta_id ) values  ( ?, ? )');
            
            $consulta->bindParam( 1,  $this->poll_id );
            $consulta->bindParam( 2,  $this->respuesta_id );
            $resultado = $consulta->execute();
            $this->resultado_id = $this->db->lastInsertId();
        }
        else
        {
            $consulta = $this->db->prepare('update poll_resultados set poll_id = ?, respuesta_id  where resultado_id = ?');
            
            $consulta->bindParam( 1,  $this->poll_id );
            $consulta->bindParam( 2,  $this->respuesta_id );
            $consulta->bindParam( 3,  $this->resultado_id );
            
            $resultado = $consulta->execute();
        }
        
        return $resultado;
    }
    
	
	public function getResultados( $encuesta_id)
    {
        
      
	   $consulta = $this->db->prepare('select poll_preguntas.pregunta,poll_preguntas.pregunta_id, poll_respuestas.respuesta, count(*) as total from poll_preguntas, poll_respuestas, poll_resultados where poll_preguntas.pregunta_id = poll_respuestas.pregunta_id and poll_respuestas.respuesta_id = poll_resultados.respuesta_id and poll_preguntas.encuesta_id = ? group by poll_preguntas.pregunta, poll_preguntas.pregunta_id,poll_respuestas.respuesta');
       $consulta->bindParam( 1,  $encuesta_id);
       $consulta->execute();
       $subtotales = $consulta->fetchAll();

       $consulta = $this->db->prepare('select poll_preguntas.pregunta, count(*) as total from poll_preguntas, poll_respuestas, poll_resultados where poll_preguntas.pregunta_id = poll_respuestas.pregunta_id and poll_respuestas.respuesta_id = poll_resultados.respuesta_id and poll_preguntas.encuesta_id = ? group by poll_preguntas.pregunta');
       $consulta->bindParam( 1,  $encuesta_id);
       $consulta->execute();
       $totales = $consulta->fetchAll();
  
       for( $i = 0; $i < count( $subtotales ); $i++ )
       {
            foreach( $totales as $total )
            {
                if( $subtotales[$i]['pregunta'] == $total['pregunta'])
                {
                    $subtotales[$i]['porcentaje'] = $subtotales[$i]['total'] *100 / $total['total'];
                }
            }
       }

       return $subtotales;
       

    }
    
	
	
}
?>